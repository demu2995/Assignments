%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Declan Murray
% 104700338
% ASEN 4057
% Assignment 1
% Question 3
% Due: 1/25/2019
% Created: 1/21/2019
% Modified: 1/21/2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Problem 3

%housekeeping 
clc, clear all, close all;

%enter variables
r = 3;% m
Wpayload = 5;%kg
Wbe = 0.6;%kg
MW = 4.02;% molecular weight

%find maxattainable height
hmax = maxHeight(r, Wpayload, Wbe, MW);

fprintf('\nThe maximum height reached by the balloon is %d meters\n', hmax);