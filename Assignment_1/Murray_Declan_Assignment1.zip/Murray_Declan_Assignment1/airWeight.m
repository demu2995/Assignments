%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Declan Murray
% 104700338
% ASEN 4057
% Assignment 1
% Question 3 - weight of air function
% Due: 1/25/2019
% Created: 1/21/2019
% Modified: 1/21/2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ Wair ] = airWeight( r, h )
%use inputed altitdude to calculate pres and Temperature
[T, P] = presTemp(h);

%calculate density
rho = P/(0.2869*(T + 273.1));

% weight of air
Wair = 4*pi*rho*r^3/3;


end

