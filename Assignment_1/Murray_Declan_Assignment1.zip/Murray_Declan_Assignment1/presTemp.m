%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Declan Murray
% 104700338
% ASEN 4057
% Assignment 1
% Question 3 - pressure temperature function
% Due: 1/25/2019
% Created: 1/21/2019
% Modified: 1/21/2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ T, P ] = presTemp( h )
% this function will output the pressure and temperature based on altitude

if h <= 11000
    T = 15.04 - 0.00649.*h;
    P = 101.29 * ((T + 273.1)./288.08).^5.256;
elseif h > 11000 && h <= 25000
    T = -56.46;
    P = 22.65.*exp(1.73 - 0.000157.*h);
elseif h > 25000
    T = -131.21 + 0.00299.*h;
    P = 2.488.*((T + 273.1)./216.6).^-11.388;
end



end

