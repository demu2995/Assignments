%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Declan Murray
% 104700338
% ASEN 4057
% Assignment 1
% Question 1
% Due: 1/25/2019
% Created: 1/16/2019
% Modified: 1/16/2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Problem 1
%housekeeping
clc, clear all, close all;

% declare constants
g = -9.8;%m/s^2

%first ask user for input
prompt = {'Enter Angle of Launch (degrees): ', 'Enter Initial Airspeed (m/s): '};
userIn = inputdlg(prompt);
theta = str2num(cell2mat(userIn(1)));
V = str2num(cell2mat(userIn(2)));

%set up equations
%introduce t variable
t = linspace(0,1000,10000);
x = V*cosd(theta).*t;
y = .5*g.*t.^2 + V*sind(theta).*t;
        
% find when y is grater than 0
posval = find(y >= 0);
posval(end) = posval(end)+1;
%plot the values
figure;
subplot(1,2,1)
plot(t(posval), x(posval))
xlabel('Time (s)')
ylabel('Horizontal Distance (m)');
title('Horizontal Distance vs. Time')

subplot(1,2,2)
plot(t(posval), y(posval))
xlabel('Time (s)')
ylabel('Vertical Distance (m)')
title('Vertical Distance vs. Time')
ylim([0 max(y)])
        
        
        
        
        