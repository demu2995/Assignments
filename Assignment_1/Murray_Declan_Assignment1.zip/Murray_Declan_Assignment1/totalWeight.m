%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Declan Murray
% 104700338
% ASEN 4057
% Assignment 1
% Question 3 - Total weight function
% Due: 1/25/2019
% Created: 1/21/2019
% Modified: 1/21/2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ Wtot ] = totalWeight( r, Wpayload, Wbe, MW )

%Calculate weight of gas in the balloon
rho = 1.225;
Wgas = 4*pi*rho*r^3/3 * (MW/28.966);

%total weight
Wtot = Wpayload+Wbe+Wgas;


end

