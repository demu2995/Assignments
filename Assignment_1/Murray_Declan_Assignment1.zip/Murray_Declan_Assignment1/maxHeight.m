%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Declan Murray
% 104700338
% ASEN 4057
% Assignment 1
% Question 3 - max Height function
% Due: 1/25/2019
% Created: 1/21/2019
% Modified: 1/21/2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ h ] = maxHeight( r, Wpayload, Wbe, MW )
%get the total weight and air weight
Wtot = totalWeight(r, Wpayload, Wbe, MW);
h = 0;
Wair = airWeight(r,h);
%initiate while loop
while Wtot <= Wair
    Wair = airWeight(r,h);
    h = h+10;
end

end

