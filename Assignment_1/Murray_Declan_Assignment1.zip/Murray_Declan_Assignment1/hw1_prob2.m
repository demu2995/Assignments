%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Declan Murray
% 104700338
% ASEN 4057
% Assignment 1
% Question 2
% Due: 1/25/2019
% Created: 1/17/2019
% Modified: 1/21/2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Problem 2

%housekeeping
clc, clear all, close all;

% introduce x and y matrices
x = [-3 12.1 20 0 8 3.7 -5.6 0.5 5.8 10];
y = [-11.06 58.95 109.73 3.15 44.83 21.29 -27.29 5.11 34.01 43.25];

%Cl and alpha
alpha = [-5 -2 0 2 3 5 7 10 14];
Cl = [-0.008 -0.003 0.001 0.005 0.007 0.006 0.009 0.017 0.019];

%test m and b values
[m, b] = bestfitline(x,y);

%solve for best fit of alpha and Cl
[m1,b1] = bestfitline(alpha,Cl);
syms xx
yfunc = m1*xx + b1;

%plot best fit line on top
scatter(alpha,Cl, 'o')
hold on
fplot(yfunc)
grid on
title('C_{L} vs. Angle of Attack for Scale F-117 Nighthawk');
xlabel('\alpha (^o)')
ylabel('C_{L}')
legend('Actual Values', 'Best fit Line' ,'Location', 'southeast')





