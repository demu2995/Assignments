%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Declan Murray
% 104700338
% ASEN 4057
% Assignment 1
% Question 2 - best fit line function
% Due: 1/25/2019
% Created: 1/21/2019
% Modified: 1/21/2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ m, b ] = bestfitline( x,y )
%Input letter variables
A = sum(x);
B = sum(y);
C = sum(x.*y);
D = sum(x.^2);
N = length(x);
%calculate m and b
m = (A*B - N*C)/(A^2 - N*D);
b = (A*C - B*D)/(A^2 - N*D);

end

